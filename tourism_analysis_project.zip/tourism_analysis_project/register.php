<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn = new mysqli("localhost", "root", "", "tourism_analysis_db");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm-password'];

    if ($password !== $confirm_password) {
        echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    const errBox = document.getElementById('error-box');
                    errBox.style.display = 'block';
                    errBox.innerText = 'Passwords do not match!';
                });
              </script>";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $hashed_password);

        if ($stmt->execute()) {
            echo "<script>alert('Registration successful!');</script>";
        } else {
            echo "<script>alert('Error: " . $stmt->error . "');</script>";
        }

        $stmt->close();
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Register</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: #F5FFF8;
    }

    .container {
      display: flex;
      max-width: 950px;
      margin: 50px auto;
      background: #FFFFFF;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 8px 24px rgba(0,0,0,0.2);
    }

    .left-panel {
      flex: 1;
      background: url('images/registerpage.jpg') no-repeat center center;
      background-size: cover;
    }

    .right-panel {
      flex: 1;
      padding: 40px 30px;
      background: #FFFFFF;
    }

    .right-panel h2 {
      color: #2E7D32;
      text-align: center;
      margin-bottom: 25px;
      font-size: 28px;
    }

    .input-box {
      position: relative;
      margin-bottom: 20px;
    }

    .input-box input {
      width: 100%;
      padding: 12px 15px 12px 45px;
      border: 1px solid #C8E6C9;
      border-radius: 8px;
      font-size: 15px;
      background: #FFFFFF;
      color: #333;
      transition: 0.3s;
    }

    .input-box input:focus {
      outline: none;
      border-color: #A5D6A7;
      box-shadow: 0 0 6px #A5D6A7;
    }

    .input-box i {
      position: absolute;
      top: 50%;
      left: 14px;
      transform: translateY(-50%);
      color: #2E7D32;
      font-size: 16px;
    }

    button {
      width: 100%;
      padding: 12px;
      background-color: #4CAF50;
      color: #FFFFFF;
      font-size: 16px;
      font-weight: bold;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    button:hover {
      background-color: #388E3C;
    }

    .footer {
      text-align: center;
      margin-top: 20px;
      font-size: 14px;
    }

    .footer a {
      color: #2E7D32;
      text-decoration: none;
    }

    .footer a:hover {
      text-decoration: underline;
    }

    .error-box {
      display: none;
      margin-bottom: 15px;
      background: #FFDADA;
      color: #D32F2F;
      padding: 12px;
      border-radius: 8px;
      font-weight: bold;
      text-align: center;
    }

    @media (max-width: 768px) {
      .container {
        flex-direction: column;
      }

      .left-panel {
        height: 250px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="left-panel"></div>

    <div class="right-panel">
      <h2>Register</h2>
      <div id="error-box" class="error-box"></div>

      <form method="POST">
        <div class="input-box">
          <i class="fas fa-user-circle"></i>
          <input type="text" name="name" placeholder="Full Name" required />
        </div>

        <div class="input-box">
          <i class="fas fa-envelope"></i>
          <input type="email" name="email" placeholder="Email Address" required />
        </div>

        <div class="input-box">
          <i class="fas fa-lock"></i>
          <input type="password" name="password" placeholder="Password" required />
        </div>

        <div class="input-box">
          <i class="fas fa-lock"></i>
          <input type="password" name="confirm-password" placeholder="Confirm Password" required />
        </div>

        <button type="submit">Register</button>
      </form>

      <div class="footer">
        Already have an account? <a href="login.php">Login Here</a>
      </div>
    </div>
  </div>
</body>
</html>
