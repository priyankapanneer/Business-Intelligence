<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn = new mysqli("localhost", "root", "", "tourism_analysis_db");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];

            header("Location: dashboard.php");
            exit();
        } else {
            $error_message = "Invalid password.";
        }
    } else {
        $error_message = "No account found with that email.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <style>
    :root {
      --mint-cream: #F5FFF8;
      --leaf-green: #4CAF50;
      --light-moss: #A5D6A7;
      --snow-white: #FFFFFF;
      --soft-fern: #C8E6C9;
      --forest-pine: #2E7D32;
      --evergreen-hover: #388E3C;
      --rusty-red: #D32F2F;
    }

    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: var(--mint-cream);
    }

    .page-wrapper {
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .container {
      display: flex;
      max-width: 950px;
      background: #FFFFFF;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 8px 24px rgba(0,0,0,0.2);
      width: 100%;
    }

    .left-panel {
      flex: 1;
      background: url('images/loginpage.jpg') no-repeat center center;
      background-size: cover;
    }

    .right-panel {
      flex: 1;
      padding: 40px 30px;
      background: var(--snow-white);
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    h2 {
      color: var(--forest-pine);
      text-align: center;
      margin-bottom: 25px;
      font-size: 28px;
    }

    .form-group {
      position: relative;
      margin-bottom: 20px;
    }

    .form-group input {
      width: 100%;
      padding: 12px 15px 12px 45px;
      border: 1px solid var(--soft-fern);
      border-radius: 8px;
      font-size: 15px;
      background: #FFFFFF;
      color: #333;
      transition: 0.3s;
    }

    .form-group input:focus {
      outline: none;
      border-color: var(--light-moss);
      box-shadow: 0 0 6px var(--light-moss);
    }

    .form-group i {
      position: absolute;
      top: 50%;
      left: 14px;
      transform: translateY(-50%);
      color: var(--forest-pine);
      font-size: 16px;
    }

    .btn {
      width: 100%;
      padding: 12px;
      background-color: var(--leaf-green);
      color: #FFFFFF;
      font-size: 16px;
      font-weight: bold;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .btn:hover {
      background-color: var(--evergreen-hover);
    }

    .footer {
      text-align: center;
      margin-top: 20px;
      font-size: 14px;
    }

    .footer a {
      color: var(--forest-pine);
      text-decoration: none;
    }

    .footer a:hover {
      text-decoration: underline;
    }

    .error-box {
      display: <?= isset($error_message) ? 'block' : 'none' ?>;
      background: #FFDADA;
      color: var(--rusty-red);
      padding: 12px;
      border-radius: 8px;
      font-weight: bold;
      margin-bottom: 15px;
      text-align: center;
    }

    @media (max-width: 768px) {
      .container {
        flex-direction: column;
        width: 90%;
      }

      .left-panel {
        height: 250px;
      }
    }
  </style>
</head>
<body>
  <div class="page-wrapper">
    <div class="container">
      <div class="left-panel"></div>

      <div class="right-panel">
        <h2>Login</h2>
        <div class="error-box"><?= isset($error_message) ? $error_message : '' ?></div>

        <form method="POST">
          <div class="form-group">
            <i class="fas fa-envelope"></i>
            <input type="email" name="email" placeholder="Email Address" required />
          </div>

          <div class="form-group">
            <i class="fas fa-lock"></i>
            <input type="password" name="password" placeholder="Password" required />
          </div>

          <button type="submit" class="btn">Login</button>
        </form>

        <div class="footer">
          Don't have an account? <a href="register.php">Register Here</a>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
