<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$user_name = $_SESSION['user_name'];
$user_email = $_SESSION['user_email'];

if (isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tourism Dashboard Project</title>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
    body.light-theme {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
        background: #e0f7fa;
        color: #004d40;
    }

    body.dark-theme {
        background: #263238;
        color: #e0f7fa;
    }

    .main-container {
        display: flex;
        min-height: 100vh;
    }

    .sidebar {
        width: 220px;
        background-color: #00bcd4;
        padding: 20px 10px;
        display: flex;
        flex-direction: column;
    }

    .sidebar button {
        background: transparent;
        color: #ffffff;
        border: none;
        padding: 12px 10px;
        margin-bottom: 10px;
        text-align: left;
        font-size: 16px;
        cursor: pointer;
        border-radius: 5px;
        transition: background 0.4s ease;
    }

    .sidebar button.active,
    .sidebar button:hover {
        background: linear-gradient(90deg, #00acc1, #26c6da);
    }

    .content {
        flex-grow: 1;
        padding: 30px;
    }

    h1 {
        text-align: center;
        margin-bottom: 30px;
        color: #006064;
    }

    .cinzel-text {
        font-family: 'Cinzel', serif !important;
    }

    .tab-content {
        display: none;
        background: #ffffff;
        padding: 20px;
        border-left: 8px solid #00bcd4;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 188, 212, 0.1);
    }

    .dark-theme .tab-content {
        background: #37474f;
        color: #e0f7fa;
        border-left-color: #26c6da;
    }

    .tab-content.active {
        display: block;
    }

    .typing-effect {
        overflow: hidden;
        border-right: .15em solid #00acc1;
        white-space: nowrap;
        animation: typing 4s steps(40, end), blink-caret .75s step-end infinite;
    }

    @keyframes typing {
        from { width: 0 }
        to { width: 100% }
    }

    @keyframes blink-caret {
        from, to { border-color: transparent }
        50% { border-color: #00acc1 }
    }

    ul {
        list-style: none;
        padding-left: 20px;
    }

    li {
        margin-bottom: 10px;
    }

    .theme-toggle,
    .logout-btn {
        position: fixed;
        top: 20px;
        padding: 10px 15px;
        font-weight: bold;
        border: none;
        cursor: pointer;
        border-radius: 5px;
        z-index: 999;
    }

    .theme-toggle {
        left: 20px;
        background-color: #00acc1;
        color: white;
    }

    .logout-btn {
        right: 20px;
        background-color: #00838f;
        color: white;
    }

    .logout-btn:hover,
    .theme-toggle:hover {
        background: linear-gradient(45deg, #0097a7, #00e5ff);
    }

    .intro {
        text-align: center;
        margin-bottom: 20px;
    }

    #team {
        background-image: url('https://via.placeholder.com/1500x800.png');
        background-size: cover;
        background-position: center;
        padding: 40px 20px;
        border-radius: 10px;
    }

    .team-container {
        display: flex;
        flex-direction: row;
        align-items: center;
        gap: 20px;
        margin-top: 30px;
    }

    .team-card {
        background: rgba(255, 255, 255, 0.85);
        border-left: 5px solid #00bcd4;
        padding: 20px;
        border-radius: 10px;
        width: 260px;
        box-shadow: 0 0 10px rgba(0, 188, 212, 0.2);
        text-align: center;
    }

    .team-card img {
        border-radius: 50%;
        margin-bottom: 15px;
    }

    .team-card a {
        text-decoration: none;
        color: #00838f;
        font-size: 20px;
    }

    .team-card a:hover {
        color: #006064;
    }

    .dark-theme #team h3,
    .dark-theme #team p,
    .dark-theme #team a {
        color: #e0f7fa !important;
    }

    .dark-theme #team .team-card {
        background: rgba(38, 50, 56, 0.95);
        border-left-color: #26c6da;
    }

    @media (max-width: 768px) {
        .main-container {
            flex-direction: column;
        }

        .sidebar {
            flex-direction: row;
            overflow-x: auto;
            width: 100%;
            padding: 10px;
        }

        .sidebar button {
            flex: 1;
            font-size: 14px;
            white-space: nowrap;
            margin: 0 5px;
        }
    }
    </style>
</head>

<body class="light-theme">

<form method="POST">
    <button type="submit" name="logout" class="logout-btn">Logout</button>
</form>

<button class="theme-toggle" onclick="toggleTheme()">🌗 Toggle Theme</button>

<h1 class="cinzel-text">IBM Cognos Tourism Project</h1>

<div class="main-container">
    <div class="sidebar">
        <button onclick="showTab('title')" class="active">Title</button>
        <button onclick="showTab('description')">Description</button>
        <button onclick="showTab('team')">Team</button>
        <button onclick="showTab('dashboard')">Dashboard</button>
    </div>

    <div class="content">
        <div id="title" class="tab-content active">
            <div class="intro">
                <p class="cinzel-text"><strong>Unlocking travel trends through intelligent data dashboards</strong></p>
                <p class="typing-effect cinzel-text"><strong>🌍 Insightful Indian Tourism Explorer</strong></p>
            </div>
            <ul>
                <li class="cinzel-text">🔍 Data-driven tourism analysis</li>
                <li class="cinzel-text">📊 Interactive IBM Cognos dashboard</li>
                <li class="cinzel-text">💡 Insights for policy makers and travelers</li>
            </ul>
        </div>

        <div id="description" class="tab-content">
            <h2 class="cinzel-text">Project Description</h2>
            <ul>
                <li class="cinzel-text">📌 Analyzes visitor data to find patterns in travel behavior across India.</li>
                <li class="cinzel-text">📂 Uses official tourism data from Government and UNWTO.</li>
            </ul>
        </div>

        <div id="team" class="tab-content" style="text-align: center; padding: 40px 20px;">
            <h2 class="cinzel-text" style="color: white;">Team Members & Roles</h2>
            <div class="team-container">
                <div class="team-card">
                    <img src="images/priyanka.jpg" alt="Priyanka" width="100" height="100">
                    <h3 class="cinzel-text">Priyanka P</h3>
                    <p class="cinzel-text"><strong>Project Lead & BackEnd Developer</strong></p>
                    <p class="cinzel-text" style="font-size: 14px;">Leads the project and develops backend logic & database.</p>
                    <a href="https://www.linkedin.com/in/priyanka-panneerselvam" target="_blank"><i class="fab fa-linkedin"></i></a>
                </div>

                <div class="team-card">
                    <img src="images/mukesh.jpg" alt="Mukesh" width="100" height="100">
                    <h3 class="cinzel-text">Mukesh K</h3>
                    <p class="cinzel-text"><strong>UI/UX Designer & FrontEnd Developer</strong></p>
                    <p class="cinzel-text" style="font-size: 14px;">Designs the UI and implements front-end features.</p>
                    <a href="https://www.linkedin.com/in/mukesh-kumar" target="_blank"><i class="fab fa-linkedin"></i></a>
                </div>

                <div class="team-card">
                    <img src="images/sriharish.jpg" alt="Sriharish" width="100" height="100">
                    <h3 class="cinzel-text">Sriharish S</h3>
                    <p class="cinzel-text"><strong>Data Analyst & Cognos Designer</strong></p>
                    <p class="cinzel-text" style="font-size: 14px;">Builds IBM Cognos dashboards and interprets tourism data.</p>
                    <a href="https://www.linkedin.com/in/sriharish" target="_blank"><i class="fab fa-linkedin"></i></a>
                </div>
            </div>
        </div>

        <div id="dashboard" class="tab-content">
            <h2 class="cinzel-text">Project Dashboard</h2>
            <div style="text-align:center; margin-top: 20px;">
                <iframe 
                    src="https://us1.ca.analytics.ibm.com/bi/?perspective=dashboard&pathRef=.my_folders%2FBI%2Bproject&action=view&mode=dashboard&subView=model00000196967ff7d6_00000001" 
                    width="100%" 
                    height="600px" 
                    style="border: 2px solid #00bcd4; border-radius: 10px;"
                    allowfullscreen>
                </iframe>
                <p style="margin-top: 10px;" class="cinzel-text"><strong>Interactive Tourism Dashboard powered by IBM Cognos</strong></p>
            </div>
        </div>
    </div>
</div>

<script>
function showTab(tabName) {
    const tabs = document.querySelectorAll('.tab-content');
    tabs.forEach(tab => tab.classList.remove('active'));
    const buttons = document.querySelectorAll('.sidebar button');
    buttons.forEach(button => button.classList.remove('active'));
    document.getElementById(tabName).classList.add('active');
    document.querySelector(`button[onclick="showTab('${tabName}')"]`).classList.add('active');
}

function toggleTheme() {
    document.body.classList.toggle('light-theme');
    document.body.classList.toggle('dark-theme');
}
</script>

</body>
</html>
